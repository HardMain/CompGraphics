import numpy as np
import random
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

num_levels = 7
matrix_size = 2 ** (num_levels - 1)
elevation = np.zeros((matrix_size + 1, matrix_size + 1))

for level in range(num_levels):
    step_size = matrix_size // 2 ** level
    for row in range(0, matrix_size + 1, step_size):
        skip_step = 1 - (row // step_size) % 2 if level > 0 else 0
        for col in range(step_size * skip_step, matrix_size + 1, step_size * (1 + skip_step)):
            direction_flag = 1 - (col // step_size) % 2 + 2 * skip_step if level > 0 else 3
            row_offset, col_offset = step_size * (1 - direction_flag // 2), step_size * (1 - direction_flag % 2)
            neighbor1 = elevation[row - row_offset, col - col_offset]
            neighbor2 = elevation[row + row_offset, col + col_offset]
            avg_height = (neighbor1 + neighbor2) / 2.0
            random_variation = step_size * (random.random() - 0.5)
            elevation[row, col] = avg_height + random_variation if level > 0 else 0

x_grid, y_grid = np.linspace(-1, 1, matrix_size + 1), np.linspace(-1, 1, matrix_size + 1)
x_grid, y_grid = np.meshgrid(x_grid, y_grid)

fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(111, projection='3d')
surface = ax.plot_surface(x_grid, y_grid, elevation, cmap='terrain', edgecolor='none')

ax.set_xlabel('')
ax.set_ylabel('')
ax.set_zlabel('')

ax.xaxis.set_tick_params(labelleft=False, labelbottom=False)
ax.yaxis.set_tick_params(labelleft=False, labelbottom=False)
ax.zaxis.set_tick_params(labelleft=False, labelbottom=False, labelright=False)

ax.grid(True)
ax.xaxis._axinfo['grid'].update(color='blue', linestyle='--', linewidth=1)
ax.yaxis._axinfo['grid'].update(color='red', linestyle=':', linewidth=2)
ax.zaxis._axinfo['grid'].update(color='green', linestyle='-.', linewidth=0.5)

plt.show()
